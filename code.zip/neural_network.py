#Программа предназначена для создания нейронной сети и ее обучения
#Автор: Сафина А.М.
#На вход ничего не принимается
#Выходные данные: сигнал о завершении процесса обучения

from tensorflow.python.keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D
from keras.layers import Activation, Dropout, Flatten, Dense

train_dir_f = 'C:/Users/Алина/Desktop/КР/unificated/train/f'
train_dir_m = 'C:/Users/Алина/Desktop/КР/unificated/train/m'
test_dir_f = 'C:/Users/Алина/Desktop/КР/unificated/test/f'
test_dir_m = 'C:/Users/Алина/Desktop/КР/unificated/test/m'
datagen = ImageDataGenerator(rescale=1. / 255)
img_width, img_height = 215, 190
input_shape = (img_width, img_height, 3)
epochs = 40
batch_size = 20
train_samples = 17608
test_samples = 2017

model = Sequential()
model.add(Conv2D(32, (3, 3), input_shape=input_shape))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(32, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(64, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Flatten())
model.add(Dense(64))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(1))
model.add(Activation('sigmoid'))